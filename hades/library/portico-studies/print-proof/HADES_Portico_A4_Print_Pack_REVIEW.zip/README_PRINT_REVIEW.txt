HADES Portico A4 Print and Phone Optical Specimens / PUBLIC REVIEW
These are browser-rendered digital A4 outputs. Print at Actual Size 100%, measure the 50mm vector ruler with a real physical ruler; physical testing remains OPEN.
Original owned logo PNG is embedded unchanged twice in the source SVGs. Only #EF4B32 is owner approved; neutrals and fonts proposals. No licensed Mikhak tested. No FINAL.
Human 48/96 CSS px results must be separately recorded on the bilingual observation page.
