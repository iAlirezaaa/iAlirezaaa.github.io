HADES Section Cuts | PUBLIC REVIEW | 2026-11-22
Three independent original vectors, three native-size PNG/JPEG/WebP groups, one contact sheet, JSON manifest.
Only vermilion #EF4B32 is owner-approved; all supporting neutrals and design layouts are PROPOSED.
No original logo is inside these backgrounds. Never redraw, recolor or trace the original.
For any original white logo over a light field, use the unchanged original on a SEPARATE dark plaque.
Not FINAL. Real-phone recognition, physical A4 print and genuine Mikhak tests remain OPEN.
