HADES Architectural Section Cuts / PUBLIC REVIEW
3 editable SVG architectural background fields: 16:9, 9:16, 1:1.
Only owner-approved accent #EF4B32. All supporting neutrals proposed.
This pack does NOT contain any logo. For original white logo over pale Bone, put untouched original raster onto a separate charcoal plate.
No FINAL. Original four logos and manifest unchanged; Pattern02 private; Pattern03 stopped.
English https://ialirezaaa.github.io/hades/library/backgrounds/section-cuts/
فارسی https://ialirezaaa.github.io/hades/fa/library/backgrounds/section-cuts/
