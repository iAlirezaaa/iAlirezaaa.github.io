HADES Quiet Courts / PUBLIC REVIEW / 2026-11-23
Three independent architecture SVGs and nine native-resolution raster exports.
Only #EF4B32 approved. Neutrals and typography proposed.
Four owner logo originals and their manifest are untouched.
On light backgrounds, an original white mark belongs on a separate dark plate.
Physical phone, print, real Mikhak, FINAL: OPEN.
