HADES Motion Delivery - PUBLIC REVIEW

1. Extract all five files into a single folder.
2. Open motion-proof.html and load your local video and the bundled square
   title PNG. The preview allows experimentation; a cropped title cannot
   be downloaded. This does not certify contrast.
3. For a contrast report, have Python 3 and FFmpeg (ffmpeg and ffprobe) on
   PATH. Install Pillow and NumPy: python -m pip install Pillow numpy
4. For a square SDR clip with rotation baked into the pixels, run:
   python temporal_contrast.py clip.mp4 HADES_Square_Title_1080_REVIEW.png report.json
   The indexed transparent PNG is accepted as-is. If you reposition it,
   use the new PNG as the overlay and run the audit again.
5. Open temporal-contrast.html and select report.json. Check individual
   frames as well as the pass count. Only near-opaque, non-accent title
   pixels are measured; this is not human, device or print approval.

Source video and native portrait/landscape overlays are not included.
