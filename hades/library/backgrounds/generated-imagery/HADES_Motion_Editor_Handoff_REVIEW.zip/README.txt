HADES / PUBLIC REVIEW — MOTION EDITOR HANDOFF
2026-11-27
Only files already in the public REVIEW library are packaged.
1. Three SVG frame guides: proposed 5% motion / 10% title safe areas.
2. SRT / WebVTT tracks and CSV: 24 fps, 144 frames, 6 seconds.
3. JSON: proposed -26 px horizontal translation, portrait unchanged.
4. Square PNG: indexed derivative only; not a native RGBA master.
5. Python renderer requires Python 3, FFmpeg and FFprobe, actual 24fps footage, and the exact native title PNG matching its pinned SHA-256. Example:
   python hades_composite.py landscape footage.mp4 HADES_Landscape_Native_REVIEW.png proof.mp4
   Output is a silent REVIEW proof and JSON receipt. Check contrast on real footage.
NOT INCLUDED: native landscape/portrait PNGs, original or test MP4s.
NLE import, original-footage contrast, Mikhak, print and hosted HTTP are OPEN.
No mark may be redrawn, recolored or replaced. No FINAL approval.
