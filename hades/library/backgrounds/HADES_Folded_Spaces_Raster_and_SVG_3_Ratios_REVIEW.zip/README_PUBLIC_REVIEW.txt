HADES FOLDED SPACES | PUBLIC REVIEW | SVG + PNG + JPEG + WEBP
Only #EF4B32 approved; all neutrals proposed. Not FINAL.
No logos included. New renders, not prior conversation raster bytes.
