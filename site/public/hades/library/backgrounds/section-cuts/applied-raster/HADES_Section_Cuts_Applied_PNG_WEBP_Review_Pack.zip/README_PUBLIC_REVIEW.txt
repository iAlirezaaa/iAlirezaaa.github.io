HADES SECTION CUTS / APPLIED COVERS — PUBLIC REVIEW
Three existing unchanged vector covers rendered at 1920x1080, 1080x1920 and 1080x1080.
Six full-size PNG/WebP files, a contact image and JSON SHA-256 manifest.
Original embedded owner logo verified against SHA-256 79867ef2cea0777a277df45a2754ea012ff552d466963f8cb831e5940a5cafb7.
No original logo bytes or four-logo manifest modified. Detached dark plaque preserved.
Only #EF4B32 is owner-approved; neutral swatches, typefaces and compositions remain REVIEW.
No physical-phone, print or authentic-Mikhak pass claimed; no FINAL approval.
