PUBLIC REVIEW / NOT FINAL
Extract all files; keep frames and plates beside the blend. Blender 4.4+; 24 fps; cut frame 16. Synthetic plates only.
