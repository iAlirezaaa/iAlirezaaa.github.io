HADES Motion Delivery - PUBLIC REVIEW
Square PNG: 1080x1080, indexed transparent; existing limited contrast test only.
Open motion-proof.html locally; supply your own matching video and PNG.
Run python temporal_contrast.py --help for CLI usage; FFmpeg and Python dependencies required.
Open temporal-contrast.html and load the generated JSON.
Source videos and portrait/landscape native overlays are not included.
Mikhak, physical print, and live HTTP remain OPEN. No FINAL.
