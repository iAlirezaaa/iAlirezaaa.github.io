HadesRealm Village v2 — preserved backup
Snapshot: ff5790cd6637cd6b12ecbb955a6bf53a254021a1

playable/ contains the original published build, byte-for-byte.
source/ contains its editable source, package lock and tests.
Serve playable/ with an HTTP server, or run npm ci and npm run dev in source/.
Game progress remains browser-local and is not included in this public backup.
No new version can overwrite this snapshot.

Public archive: https://ialirezaaa.github.io/HadesRealm/archive/village-v2/
